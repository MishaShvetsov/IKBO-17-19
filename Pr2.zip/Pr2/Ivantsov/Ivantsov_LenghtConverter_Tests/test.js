const chai = window.chai
const expect = chai.expect

//___FEET___//
describe('Feet in Meters', () => {
    it('CHETKO 👍', () => {
        expect(FeetInMeters(2)).to.deep.equal('0.61')
    })
})
describe('Feet in Iches', () => {
    it('CHETKO 👍', () => {
        expect(FeetInInches(2)).to.deep.equal('24.00')
    })
})
describe('Feet in Cm', () => {
    it('CHETKO 👍', () => {
        expect(FeetInInCm(2)).to.deep.equal('61')
    })
})
describe('Feet in Millimeters', () => {
    it('CHETKO 👍', () => {
        expect(FeetInInMillimeters(2)).to.deep.equal('0.67')
    })
})
describe('Feet in Kilometers', () => {
    it('CHETKO 👍', () => {
        expect(FeetInInKilometers(2)).to.deep.equal('0.00061')
    })
})
describe('Feet in Miles', () => {
    it('CHETKO 👍', () => {
        expect(FeetInInMiles(2)).to.deep.equal('0.00038')
    })
})



//___METERS___//
describe('Meters in Feet', () => {
    it('CHETKO 👍', () => {
        expect(MetersInFeet(2)).to.deep.equal('6.56')
    })
})
describe('Meters in Inches', () => {
    it('CHETKO 👍', () => {
        expect(MetersInInches(2)).to.deep.equal('78.74')
    })
})
describe('Meters in Cm', () => {
    it('CHETKO 👍', () => {
        expect(MetersInCm(2)).to.deep.equal('200')
    })
})
describe('Meters in Millimeters', () => {
    it('CHETKO 👍', () => {
        expect(MetersInMillimeters(2)).to.deep.equal('2.19')
    })
})
describe('Meters in Kilometers', () => {
    it('CHETKO 👍', () => {
        expect(MetersInKilometers(2)).to.deep.equal('0.00200')
    })
})
describe('Meters in Miles', () => {
    it('CHETKO 👍', () => {
        expect(MetersInMiles(2)).to.deep.equal('0.00124')
    })
})



//___INCHES___//
describe('Inches in Feet', () => {
    it('CHETKO 👍', () => {
        expect(InchesInFeet(2)).to.deep.equal('0.167')
    })
})
describe('Inches in Meters', () => {
    it('CHETKO 👍', () => {
        expect(InchesInMeters(2)).to.deep.equal('0.051')
    })
})
describe('Inches in Cm', () => {
    it('CHETKO 👍', () => {
        expect(InchesInCm(2)).to.deep.equal('5.08')
    })
})
describe('Inches in Millimeters', () => {
    it('CHETKO 👍', () => {
        expect(InchesInMillimeters(2)).to.deep.equal('0.022')
    })
})
describe('Inches in Kilometers', () => {
    it('CHETKO 👍', () => {
        expect(InchesInKilometers(2)).to.deep.equal('0.000051')
    })
})
describe('Inches in Miles', () => {
    it('CHETKO 👍', () => {
        expect(InchesInMiles(2)).to.deep.equal('0.000012')
    })
})



//___CM___//
describe('Cm in Feet', () => {
    it('CHETKO 👍', () => {
        expect(CmInFeet(2)).to.deep.equal('0.066')
    })
})
describe('Cm in Meters', () => {
    it('CHETKO 👍', () => {
        expect(CmInMeters(2)).to.deep.equal('0.020')
    })
})
describe('Cm in Inches', () => {
    it('CHETKO 👍', () => {
        expect(CmInInches(2)).to.deep.equal('0.79')
    })
})
describe('Cm in Millimeters', () => {
    it('CHETKO 👍', () => {
        expect(CmInInMillimeters(2)).to.deep.equal('0.022')
    })
})
describe('Cm in Kilometers', () => {
    it('CHETKO 👍', () => {
        expect(CmInInKilometers(2)).to.deep.equal('0.000020')
    })
})
describe('Cm in Miles', () => {
    it('CHETKO 👍', () => {
        expect(CmInInMiles(2)).to.deep.equal('0.000012')
    })
})



//___MILLIMETERS__//
describe('Millimeters in Feet', () => {
    it('CHETKO 👍', () => {
        expect(MillimetersInFeet(2)).to.deep.equal('6')
    })
})
describe('Millimeters in Meters', () => {
    it('CHETKO 👍', () => {
        expect(MillimetersInMeters(2)).to.deep.equal('1.83')
    })
})
describe('Millimeters in Inches', () => {
    it('CHETKO 👍', () => {
        expect(MillimetersInInches(2)).to.deep.equal('72')
    })
})
describe('Millimeters in Cm', () => {
    it('CHETKO 👍', () => {
        expect(MillimetersInCm(2)).to.deep.equal('183')
    })
})
describe('Millimeters in Kilometers', () => {
    it('CHETKO 👍', () => {
        expect(MillimetersInKilometers(2)).to.deep.equal('0.00183')
    })
})
describe('Millimeters in Miles', () => {
    it('CHETKO 👍', () => {
        expect(MillimetersInMiles(2)).to.deep.equal('0.00114')
    })
})



//___KILOMETERS___//
describe('Killometers in Feet', () => {
    it('CHETKO 👍', () => {
        expect(KilometersInFeet(2)).to.deep.equal('6562')
    })
})
describe('Killometers in Meters', () => {
    it('CHETKO 👍', () => {
        expect(KilometersInMeters(2)).to.deep.equal('2000')
    })
})
describe('Killometers in Inches', () => {
    it('CHETKO 👍', () => {
        expect(KilometersInInches(2)).to.deep.equal('78740')
    })
})
describe('Killometers in Cm', () => {
    it('CHETKO 👍', () => {
        expect(KilometersInCm(2)).to.deep.equal('200000')
    })
})
describe('Killometers in Millimeters', () => {
    it('CHETKO 👍', () => {
        expect(KilometersInMillimeters(2)).to.deep.equal('2187')
    })
})
describe('Killometers in Miles', () => {
    it('CHETKO 👍', () => {
        expect(KilometersInMiles(2)).to.deep.equal('1.24')
    })
})



//___MILES___//
describe('Miles in Feet', () => {
    it('CHETKO 👍', () => {
        expect(MilesInFeet(2)).to.deep.equal('10560.00')
    })
})
describe('Miles in Meters', () => {
    it('CHETKO 👍', () => {
        expect(MilesInMeters(2)).to.deep.equal('3219')
    })
})
describe('Miles in Inches', () => {
    it('CHETKO 👍', () => {
        expect(MilesInInches(2)).to.deep.equal('126720')
    })
})
describe('Miles in Cm', () => {
    it('CHETKO 👍', () => {
        expect(MilesInCm(2)).to.deep.equal('321869')
    })
})
describe('Miles in Millimeters', () => {
    it('CHETKO 👍', () => {
        expect(MilesInMillimeters(2)).to.deep.equal('3520')
    })
})
describe('Miles in Kilometers', () => {
    it('CHETKO 👍', () => {
        expect(MilesInKilometers(2)).to.deep.equal('3.22')
    })
})