//___FEET___//
function FeetInMeters(feet) {

  return (parseFloat(feet) / 3.2808).toFixed(2);
  
}
function FeetInInches(feet) {

  return (parseFloat(feet) * 12).toFixed(2);
  
}
function FeetInInCm(feet) {

  return (parseFloat(feet) / 0.032808).toFixed();
  
}
function FeetInInMillimeters(feet) {

  return (parseFloat(feet) * 0.33333).toFixed(2);
  
}
function FeetInInKilometers(feet) {

  return (parseFloat(feet) / 3280.8).toFixed(5);
  
}
function FeetInInMiles(feet) {

  return (parseFloat(feet) * 0.00018939).toFixed(5);
  
}



//___METERS___//
function MetersInFeet(meters) {

  return (parseFloat(meters) * 3.2808).toFixed(2);
  
}
function MetersInInches(meters) {

  return (parseFloat(meters) * 39.370).toFixed(2);
  
}
function MetersInCm(meters) {

  return (parseFloat(meters) / 0.01).toFixed();
  
}
function MetersInMillimeters(meters) {

  return (parseFloat(meters) * 1.0936).toFixed(2);
  
}
function MetersInKilometers(meters) {

  return (parseFloat(meters) / 1000).toFixed(5);
  
}
function MetersInMiles(meters) {

  return (parseFloat(meters) * 0.00062137).toFixed(5);
  
}



//___INCHES___//
function InchesInFeet(inches) {

  return (parseFloat(inches) * 0.083333).toFixed(3);
  
}
function InchesInMeters(inches) {

  return (parseFloat(inches) / 39.370).toFixed(3);
  
}
function InchesInCm(inches) {

  return (parseFloat(inches) / 0.39370).toFixed(2);
  
}
function InchesInMillimeters(inches) {

  return (parseFloat(inches)  * 0.010936).toFixed(3);
  
}
function InchesInKilometers(inches) {

  return (parseFloat(inches)  / 39370).toFixed(6);
  
}
function InchesInMiles(inches) {

  return (parseFloat(inches)  * 0.0000062137).toFixed(6);
  
}



//___CM___//
function CmInFeet(cm) {

  return (parseFloat(cm) * 0.032808).toFixed(3);
  
}
function CmInMeters(cm) {

  return (parseFloat(cm) / 100).toFixed(3);
  
}
function CmInInches(cm) {

  return (parseFloat(cm) * 0.39370).toFixed(2);
  
}
function CmInInMillimeters(cm) {

  return (parseFloat(cm) * 0.010936).toFixed(3);
  
}
function CmInInKilometers(cm) {

  return (parseFloat(cm) / 100000).toFixed(6);
  
}
function CmInInMiles(cm) {

  return (parseFloat(cm) * 0.0000062137).toFixed(6);
  
}



//___MILLIMETERS__//
function MillimetersInFeet(millimeters) {

  return (parseFloat(millimeters) * 3).toFixed();
  
}
function MillimetersInMeters(millimeters) {

  return (parseFloat(millimeters) / 1.0936).toFixed(2);
  
}
function MillimetersInInches(millimeters) {

  return (parseFloat(millimeters) * 36).toFixed();
  
}
function MillimetersInCm(millimeters) {

  return (parseFloat(millimeters) / 0.010936).toFixed();
  
}
function MillimetersInKilometers(millimeters) {

  return (parseFloat(millimeters) / 1093.6).toFixed(5);
  
}
function MillimetersInMiles(millimeters) {

  return (parseFloat(millimeters) * 0.00056818).toFixed(5);
  
}



//___KILOMETERS___//
function KilometersInFeet(kilometers) {

  return (parseFloat(kilometers) * 3280.8).toFixed();
  
}
function KilometersInMeters(kilometers) {

  return (parseFloat(kilometers) * 1000).toFixed();
  
}
function KilometersInInches(kilometers) {

  return (parseFloat(kilometers) * 39370).toFixed();
  
}
function KilometersInCm(kilometers) {

  return (parseFloat(kilometers) * 100000).toFixed();
  
}
function KilometersInMillimeters(kilometers) {

  return (parseFloat(kilometers) * 1093.6).toFixed();
  
}
function KilometersInMiles(kilometers) {

  return (parseFloat(kilometers) * 0.62137).toFixed(2);
  
}



//___MILES___//
function MilesInFeet(miles) {

  return (parseFloat(miles) * 5280).toFixed(2);
  
}
function MilesInMeters(miles) {

  return (parseFloat(miles) / 0.00062137).toFixed();
  
}
function MilesInInches(miles) {

  return (parseFloat(miles) * 63360).toFixed();
  
}
function MilesInCm(miles) {

  return (parseFloat(miles) / 0.0000062137).toFixed();
  
}
function MilesInMillimeters(miles) {

  return (parseFloat(miles) * 1760).toFixed();
  
}
function MilesInKilometers(miles) {

  return (parseFloat(miles) / 0.62137).toFixed(2);
  
}