﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApp1
{
    public class calcul
    {
        public float sep(int a, int b)
        {
            return a / b;
        }
        public float mul(int a, int b)
        {
            return a * b;
        }
        public float add(int a, int b)
        {
            return a + b;
        }
        public float sub(int a, int b)
        {
            return a - b;
        }
    }
}
