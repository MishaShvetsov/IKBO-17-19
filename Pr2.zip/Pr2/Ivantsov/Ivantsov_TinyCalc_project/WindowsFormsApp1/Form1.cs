﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        calcul c = new calcul();
        int a, b, focusedTb = 1;

        private void textBox1_Enter(object sender, EventArgs e)
        {
            focusedTb = 1;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            focusedTb = 2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("2");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("2");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("3");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("3");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("4");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("4");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("5");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("5");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("6");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("6");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("7");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("7");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("8");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("8");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("9");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("9");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("0");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("0");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            a = 0; b = 0; textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (label4.Text == " ")
            {
                MessageBox.Show("Операция не выбрана");
            }
            else
            if (label4.Text == "+")
            {
                textBox3.Text = c.add(a, b).ToString();
            }
            else
            if (label4.Text == "-")
            {
                textBox3.Text = c.sub(a, b).ToString();
            }
            else
            if (label4.Text == "/")
            {
                textBox3.Text = c.sep(a, b).ToString();
            }
            else
            if (label4.Text == "*")
            {
                textBox3.Text = c.mul(a, b).ToString();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label4.Text = "+";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            label4.Text = "-";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            label4.Text = "/";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            label4.Text = "*";
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (focusedTb == 1)
            {
                textBox1.AppendText("1");
                try
                {
                    a = int.Parse(textBox1.Text);
                }
                catch (Exception ex) { }
            }
            else
            if (focusedTb == 2)
            {
                textBox2.AppendText("1");
                try
                {
                    b = int.Parse(textBox2.Text);
                }
                catch (Exception ex) { }
            }
        }
    }
}
