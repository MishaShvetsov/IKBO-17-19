﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WindowsFormsApp1;

namespace testTINYCALC
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void take10_add15_expexted25()
        {
            int a = 10;
            int b = 15;
            float exp = 25;

            var c = new calcul();
            float resp = c.add(a, b);

            Assert.AreEqual(exp, resp);
        }

        [TestMethod]
        public void take25_divideBY5_expexted5()
        {
            int a = 25;
            int b = 5;
            float exp = 5;

            var c = new calcul();
            float resp = c.sep(a, b);

            Assert.AreEqual(exp, resp);
        }

        [TestMethod]
        public void take50_multiplyBY2_expexted100()
        {
            int a = 50;
            int b = 2;
            float exp = 100;

            var c = new calcul();
            float resp = c.mul(a, b);

            Assert.AreEqual(exp, resp);
        }
        [TestMethod]
        public void take80_substract35_expected45()
        {
            int a = 80;
            int b = 35;
            float exp = 45;

            var c = new calcul();
            float resp = c.sub(a, b);

            Assert.AreEqual(exp, resp);
        }
    }
}
