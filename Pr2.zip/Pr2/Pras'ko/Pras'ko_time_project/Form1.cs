﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timexDDD
{
    public partial class Form1 : Form
    {
        Dx exe = new Dx();

        string l1, l2, r1, r2;
        int l1_1, l2_1, r1_1, r2_1;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox4.Text = DateTime.Now.Hour.ToString();
            textBox3.Text = DateTime.Now.Minute.ToString();

            l1 = textBox1.Text;
            l2 = textBox4.Text;
            r1 = textBox2.Text;
            r2 = textBox3.Text;

            try
            {
                l1_1 = 0;
                l2_1 = 0;
                r1_1 = 0;
                r2_1 = 0;

                l1_1 = Convert.ToInt32(l1);
                l2_1 = Convert.ToInt32(l2);
                r1_1 = Convert.ToInt32(r1);
                r2_1 = Convert.ToInt32(r2);

                if (l1_1 >= 0 && l1_1 <= 23 && r1_1 >= 0 && r1_1 <= 59)
                {


                    if (exe.compare(l1_1, l2_1, r1_1, r2_1) == true)
                    {
                        textBox5.Text = "ВЕРНО";
                    }
                    else
                    {
                        textBox5.Text = "НЕПОВЕЗЛО НЕПОВЕЗЛО";
                    }
                }
                else
                {
                    textBox5.Text = "смотри что вводишь";
                }

            }
            catch (Exception ex)
            {
                textBox5.Text = "введите цифры!";
            }

            
        }
    }

    public class Dx
    {
        public bool compare(int l1, int l2, int r1, int r2)
        {
            if (l1 == l2 && r1 == r2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
   