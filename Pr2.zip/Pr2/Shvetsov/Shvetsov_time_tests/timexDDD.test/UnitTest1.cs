﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using timexDDD;

namespace timexDDD.test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void comparing_4_fields_an_false_is_expected()
        {
            int a = 11;
            int b = 22;
            int c = 33;
            int d = 44;

            bool g = false;

            var Dx = new Dx();
            bool res = Dx.compare(a, b, c, d);

            Assert.AreEqual(g, res);
        }
    }
}
