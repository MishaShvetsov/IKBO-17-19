﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using timexDDD;

namespace timexDDD.test
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void checking_the_validity_of_the_enteredvalues()
        {
            int a = 99;
            int b = -2;
            int c = 33;
            int d = 44;

            bool g = false;

            var Dx = new Dx();
            bool res = Dx.compare(a, b, c, d);

            Assert.AreEqual(g, res);
        }
    }
}
